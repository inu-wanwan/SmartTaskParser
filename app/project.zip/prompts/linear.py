from .base import BasePromptBuilder

class LinearPromptBuilder(BasePromptBuilder):
    def build(self, user_input: str, project_context: str) -> str:
        """
        Linear タスク抽出用プロンプトを構築する
        """
        common_context = self.get_common_context()
        return f"""
あなたは日本語の自然文からタスク情報を抽出し、Linear（タスク管理ツール）のIssue形式に変換するアシスタントです。

ユーザーが入力した文章を解析し、次の JSON を出力してください。
※値が不明な場合は null にしてください。

{{
  "title": string,              // タスク名（短く簡潔に）
  "description": string | null, // 詳細内容（入力文のニュアンスを含める）
  "dueDate": string | null,     // YYYY-MM-DD 形式
  "priority": number,           // 0(なし), 1(緊急), 2(高), 3(中), 4(低)
  "label": string,              // カテゴリ名を配列で指定
}}

# 現在の文脈
{common_context}

# 日付のルール
- 「今日」「明日」「来週の月曜」などの相対表現は、現在日付を基準に YYYY-MM-DD 形式に変換してください。
- 期限が不明なら "dueDate": null にしてください。

# 優先度（priority）の判定ルール
- 「至急」「すぐやる」「最優先」→ 1 (Urgent)
- 「重要」「早めに」→ 2 (High)
- 「やる」「期限あり」→ 3 (Normal)
- 「余裕があれば」「いつか」→ 4 (Low)
- 判断がつかない → 0 (No Priority)

# プロジェクト定義
{project_context}

# 出力フォーマット
- 出力は必ず **純粋な JSON だけ** にしてください。
- マークダウンのコードブロック（```json ... ```）も不要です。
- JSON以外の説明文は一切含めないでください。

# 入力文
{user_input}

JSON のみを返してください。
"""